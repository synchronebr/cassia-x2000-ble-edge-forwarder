#!/usr/bin/env python3
import struct

# Service Data UUIDs do firmware Synchroone (app_ble.c — update_adv_data)
# Payload de advertising montado pelo firmware:
#   [5][0x09]['S','y','n','c']           Local Name "Sync"
#   [15][0x16][0x40][0x51][uid 12B]     Service Data UUID 0x5140 — UID do STM32 (12 bytes)
#   [4][0x16][0x41][0x51][frame_ctr]    Service Data UUID 0x5141 — stored_frame_counter (1 byte)
#
# stored_frame_counter > 0  →  há leituras pendentes aguardando coleta
# stored_frame_counter == 0 →  sensor idle

_SERVICE_UUID_DEVICE_UID  = 0x5140
_SERVICE_UUID_PENDING_CNT = 0x5141


def parse_synchroone_adv(adv_data_hex: str):
    """
    Retorna dict se o sensor tem leituras pendentes (stored_frame_counter > 0).
    Retorna None se idle (counter == 0) ou dispositivo não-Synchroone.

    Campos do dict retornado:
      pending_count  — número de frames armazenados aguardando coleta (uint8)
      seq_num        — mesmo valor; usado pelo ConnectionManager para dedup
      uid            — UID do STM32 em hex (string de 24 chars) ou None
      error_flag     — False (reservado para versão futura com AD 0xFF)
      low_battery    — False (reservado para versão futura com AD 0xFF)
    """
    if not adv_data_hex:
        return None

    try:
        data = bytes.fromhex(adv_data_hex)
    except Exception:
        return None

    pending_count = None
    uid_hex = None

    i = 0
    while i < len(data):
        if i + 1 >= len(data):
            break
        length = data[i]
        if length == 0 or i + length >= len(data):
            break
        ad_type = data[i + 1]
        payload = data[i + 2: i + 1 + length]

        if ad_type == 0x16 and len(payload) >= 2:
            uuid = struct.unpack_from('<H', payload, 0)[0]
            if uuid == _SERVICE_UUID_PENDING_CNT and len(payload) >= 3:
                pending_count = payload[2]
            elif uuid == _SERVICE_UUID_DEVICE_UID and len(payload) >= 14:
                uid_hex = payload[2:14].hex()

        i += 1 + length

    if pending_count is None or pending_count == 0:
        return None

    return {
        'pending_count': pending_count,
        'seq_num':       pending_count,
        'uid':           uid_hex,
        'error_flag':    False,
        'low_battery':   False,
    }
