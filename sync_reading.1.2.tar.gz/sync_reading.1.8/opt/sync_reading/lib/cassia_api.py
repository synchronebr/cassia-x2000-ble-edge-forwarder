#!/usr/bin/env python3
"""
Cliente HTTP para a REST API do Cassia X2000.
Sem dependências externas — usa apenas urllib/http.client da stdlib.
"""
import http.client
from urllib.parse import urlparse


def _request(method: str, url: str, timeout: int = 5):
    """Executa uma requisição HTTP e retorna (status_code, body_str)."""
    p = urlparse(url)
    host = p.hostname
    if not host:
        raise RuntimeError("URL inválida (sem host): %s" % url)
    port = p.port or (443 if p.scheme == "https" else 80)
    path = p.path + ("?" + p.query if p.query else "")

    Conn = http.client.HTTPSConnection if p.scheme == "https" else http.client.HTTPConnection
    conn = Conn(host, port, timeout=timeout)
    try:
        conn.request(method, path, headers={"Content-Length": "0"})
        resp = conn.getresponse()
        body = resp.read().decode("utf-8", errors="ignore")
        return resp.status, body
    finally:
        try:
            conn.close()
        except Exception:
            pass


def connect_device(gateway_api: str, mac: str, chip: int, timeout: int = 5, addr_type: str = "random"):
    """
    POST /gap/nodes/{mac}/connection?chip={chip}&type={addr_type}

    addr_type: "random" (padrão — STM32WBA65 usa endereço random)
               "public" (endereço MAC fixo gravado no chip)

    Retorna (status_code, body).
    """
    url = "{}/gap/nodes/{}/connection?chip={}&type={}".format(
        gateway_api.rstrip("/"), mac, chip, addr_type
    )
    return _request("POST", url, timeout=timeout)


def disconnect_device(gateway_api: str, mac: str, timeout: int = 5):
    """
    DELETE /gap/nodes/{mac}/connection
    Retorna (status_code, body).
    """
    url = "{}/gap/nodes/{}/connection".format(gateway_api.rstrip("/"), mac)
    return _request("DELETE", url, timeout=timeout)


def pair_device(gateway_api: str, mac: str, timeout: int = 10):
    """
    POST /gap/nodes/{mac}/pair
    Estabelece link BLE encriptado/autenticado após connect_device().
    Necessário antes de escrever em características protegidas (CONFIG/PASSWORD).
    Retorna (status_code, body).
    """
    url = "{}/gap/nodes/{}/pair".format(gateway_api.rstrip("/"), mac)
    return _request("POST", url, timeout=timeout)


def set_phy(gateway_api: str, mac: str, tx_phy: int = 2, rx_phy: int = 2, timeout: int = 5):
    """
    POST /gap/nodes/{mac}/phy?tx_phy={tx_phy}&rx_phy={rx_phy}
    Solicita upgrade de PHY após conexão estabelecida.
    Retorna (status_code, body).
    """
    url = "{}/gap/nodes/{}/phy?tx_phy={}&rx_phy={}".format(
        gateway_api.rstrip("/"), mac, tx_phy, rx_phy
    )
    return _request("POST", url, timeout=timeout)


def read_handle(gateway_api: str, mac: str, handle: int, timeout: int = 5):
    """
    GET /gatt/nodes/{mac}/handle/{handle}/value
    Retorna (status_code, body).
    """
    url = "{}/gatt/nodes/{}/handle/{}/value".format(
        gateway_api.rstrip("/"), mac, handle
    )
    return _request("GET", url, timeout=timeout)


def write_handle(gateway_api: str, mac: str, handle: int, value_hex: str, timeout: int = 5):
    """
    POST /gatt/nodes/{mac}/handle/{handle}/value/{value_hex}
    Retorna (status_code, body).
    """
    url = "{}/gatt/nodes/{}/handle/{}/value/{}".format(
        gateway_api.rstrip("/"), mac, handle, value_hex
    )
    return _request("POST", url, timeout=timeout)
